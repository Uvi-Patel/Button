//
//  ViewController.swift
//  button_demo
//
//  Created by MAC on 29/05/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    
    @IBOutlet weak var btbt: UIButton!
    @IBOutlet weak var lb1: UILabel!
    
    @IBOutlet weak var btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image = UIImage(named:"aa")
        
        btbt.setImage(image, for: .normal)
        btbt.tintColor = .white
        btbt.imageView?.contentMode = .scaleAspectFit
        btbt.imageEdgeInsets = UIEdgeInsets(top:0, left:-30, bottom:0, right:0) //adjust these to have fit right //add title
        
        btbt.setTitle("Fan", for: .normal)
        btbt.setTitleColor(UIColor.black, for: .normal)
        btbt.titleEdgeInsets = UIEdgeInsets(top:0, left:10, bottom:0, right:0)
        
        
    let btn = UIButton(type: .system)
       // btn.setImage(UIImage(named: "PinkFloydWallCoverOriginalNoText.jpg"), for: UIControl.State.normal)
        btn.setTitle("I Am Button", for: .normal)
        btn.setTitleColor(UIColor.systemPink, for: .normal)
        btn.frame = CGRect(x: 15,y: 200,width: 100 ,height: 100)
        btn.backgroundColor = UIColor.yellow
        btn.tag = 5000000
        btn.addTarget(self, action: #selector(clickOnOkBtn(btn:)), for: .touchUpInside)
        // btn.sizeToFit()
        self.view.addSubview(btn)
        
        
        let btn2 = UIButton(type: .system)
        btn2.setBackgroundImage(UIImage(named: "aaaa"), for: UIControl.State.normal)
        btn2.setTitle("I Am Button Two", for: .normal)
        btn2.setTitleColor(UIColor.black, for: .normal)
        btn2.frame = CGRect(x: 150,y: 450,width: 150,height: 80)
        btn2.addTarget(self, action: #selector(btnalert(_:)), for: .touchUpInside)
    //  btn2.backgroundColor = UIColor.red
        btn2.layer.borderWidth = 2.0
        btn2.addTarget(self, action: #selector(btnaction(_:)), for: .touchDragEnter)
        self.view.addSubview(btn2)
       
       // btn3 =  UIButton(frame: CGRectMake(0,0,30,30))
       // btn3?.setBackgroundImage(UIImage(named: "123.png"), forState: UIControlState.Normal)

      
//        let btn3 = UIButton(type: .custom)
//        btn3.frame = CGRect(x: 150,y: 200,width: 200 ,height: 80)
//        btn3.backgroundColor = UIColor.gray
//        btn3.setTitle("Hello", for: UIControl.State.normal)
//        btn3.setTitleColor(UIColor.blue, for: UIControl.State.normal)
//        btn3.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
//        btn3.titleLabel?.font = UIFont(name: "GillSans-Italic", size: 20)
//
//        let icon = UIImage(named: "aa")
//        btn3.setImage(icon, for: .normal)
//        btn3.imageView?.contentMode = .scaleAspectFit
//        btn3.imageEdgeInsets = UIEdgeInsets(top: 0, left: -70, bottom: 0, right: 0)
//        self.view.addSubview(btn3)
//
//        let btn11 = UIButton(type: .custom)
//        btn11.frame = CGRect(x: 150,y: 300,width: 200 ,height: 80)
//        btn11.backgroundColor = UIColor.gray
//        btn11.setTitle("Hello", for: UIControl.State.normal)
//        btn11.setTitleColor(UIColor.blue, for: UIControl.State.normal)
//        self.view.addSubview(btn11)
        
       // let view = UIView()
      //  btn3.setTitle("Skip", for: .normal)
       /* btn3.setImage(image, for: .normal)
        btn3.semanticContentAttribute = .forceLeftToRight
        btn3.imageEdgeInsets = UIEdgeInsets(top: 0, left: -10, bottom: 0, right: 10)
        //btn3.sizeToFit()
        //view.addSubview(button)
        view.frame = btn3.bounds
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: view)*/
        
        
        let btn1 = UIButton(type: .system)
        btn1.setTitle("smart", for: .normal)
        btn1.setTitleColor(UIColor.black, for: .normal)
        btn1.frame = CGRect(x: 50,y: 330,width: 200 ,height: 100)
        btn1.backgroundColor = UIColor.green
        btn1.setImage(image, for: .normal)
        btn1.tintColor = .red
        btn1.semanticContentAttribute = .forceLeftToRight
        btn1.imageEdgeInsets = UIEdgeInsets(top: 0, left: -50, bottom: 0, right: 10)
        self.view.addSubview(btn1)
       /* btn3.setTitle("Smart", for: .normal)
        btn3.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: -10)
        btn3.setTitleColor(UIColor.white, for: .normal)*/
        
       
        
        /*  let btn5 = UIButton(type: .infoDark)
        btn5.frame = CGRect(x: 25,y: 250,width: 200 ,height: 200)
        self.view.addSubview(btn5)*/
    
        // Do any additional setup after loading the view.
    }

    @IBAction func clickOnBtn(_ sender: Any) {
        print("hii")
    }
    
    @objc func btnaction(_ sender: Any)
    {
        print("hello")
    }
    
    @objc func btnalert(_ sender: Any)
    {
        let simplealrt = UIAlertController(title: "Hello world", message: "How are You??", preferredStyle: .actionSheet)
        let okaction =  UIAlertAction(title: "ok", style: .default, handler: nil)
        simplealrt.addAction(okaction)
        self.present(simplealrt,animated: true, completion: nil)
        
    }
    
    @objc func clickOnOkBtn(btn: UIButton){
        print(" btn tag \(btn.tag)")
    }
    
    @objc func lbview()
    {
        lb1.text = "Today is Saturday"
        lb1.backgroundColor = UIColor.green
        lb1.font = .italicSystemFont(ofSize: 30)
        lb1.textColor = UIColor.black
    }
}


//public extension UIButton {
//    func alignTextUnderImage(spacing: CGFloat = 6.0) {
//        if let image = self.imageView?.image {
//            let imageSize: CGSize = image.size
//            self.titleEdgeInsets = UIEdgeInsets(top: spacing, left: -imageSize.width, bottom: -(imageSize.height), right: 0.0)
//            let labelString = NSString(string: self.titleLabel!.text!)
//            let titleSize = labelString.size(withAttributes: [NSAttributedString.Key.font: self.titleLabel!.font as Any])
//            self.imageEdgeInsets = UIEdgeInsets(top: -(titleSize.height + spacing), left: 0.0, bottom: 0.0, right: -titleSize.width)
//
//        }
//
//    }
//
//}
